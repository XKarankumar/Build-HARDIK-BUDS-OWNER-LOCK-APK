# HARDIK BUDS OWNER LOCK (prototype)

Android companion-app prototype targeting OnePlus Nord Buds 3 Pro firmware reference `155.155.101`.

## What this prototype does
- Requests Bluetooth scan permissions and scans nearby devices.
- Lets you select and locally register a device label/address as the owner device in app storage.
- Saves a local 4–8 digit app PIN.
- Provides a dark minimal interface.
- GitHub Actions builds a debug APK on push or manual run.

## Limitations / safety
This is an app-level prototype, **not** a firmware modification. It cannot force earbuds to request this PIN during Bluetooth pairing, prevent another phone from pairing, prevent factory reset, change ANC/EQ firmware controls, or guarantee automatic reconnect. Android Bluetooth scan results may hide device names/addresses depending on permission/version. The current PIN flow is a prototype and does not yet gate app launch; don't treat it as a secure vault.

## Build
Open the project in Android Studio and sync, then Build > Build APK. Or push to GitHub and run the Actions workflow. The debug APK is available in Actions > workflow run > Artifacts.
